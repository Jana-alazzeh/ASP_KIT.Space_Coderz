﻿// 📁 Controllers/ProductsController.cs

using July_Team.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

// 🛑 الصلاحية: يجب أن يكون المستخدم مسجلاً للدخول
//[Authorize]
public class ProductsController : Controller
{
    private readonly AppDbContext _db;

    public ProductsController(AppDbContext db)
    {
        _db = db;
    }
   
    // ===============================================
    // لوحة التحكم - عرض جميع المنتجات (Admin فقط)
    // ===============================================

    //[Authorize(Roles = "Admin")] // 👈 فقط Admin يستطيع الدخول
    public async Task<IActionResult> AdminIndex()
    {
        var products = await _db.Products.ToListAsync();
        // يعرض Views/Products/AdminIndex.cshtml
        return View(products);
    }

    // ===============================================
    // إنشاء منتج جديد (Admin فقط)
    // ===============================================

    [HttpGet]
    //[Authorize(Roles = "Admin")]
    public IActionResult Create()
    {
        // يعرض Views/Products/Create.cshtml
        return View();
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    //[Authorize(Roles = "Admin")]
    public async Task<IActionResult> Create(Product model)
    {
        if (ModelState.IsValid)
        {
            _db.Products.Add(model);
            await _db.SaveChangesAsync();
            return RedirectToAction(nameof(AdminIndex)); // العودة إلى لوحة التحكم
        }
        return View(model);
    }

    // ===============================================
    // تعديل منتج (Admin فقط)
    // ===============================================

    [HttpGet]
    //[Authorize(Roles = "Admin")]
    public async Task<IActionResult> Edit(int id)
    {
        var product = await _db.Products.FindAsync(id);
        if (product == null) return NotFound();
        return View(product);
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    //[Authorize(Roles = "Admin")]
    public async Task<IActionResult> Edit(Product model)
    {
        if (ModelState.IsValid)
        {
            _db.Products.Update(model);
            await _db.SaveChangesAsync();
            return RedirectToAction(nameof(AdminIndex));
        }
        return View(model);
    }

    // ===============================================
    // حذف منتج (Admin فقط)
    // ===============================================

    // نستخدم الـ POST مباشرةً للحذف لتبسيط الكود الإداري
    [HttpPost, ActionName("Delete")]
    [ValidateAntiForgeryToken]
    //[Authorize(Roles = "Admin")]
    public async Task<IActionResult> DeleteConfirmed(int id)
    {
        var product = await _db.Products.FindAsync(id);
        if (product != null)
        {
            _db.Products.Remove(product);
            await _db.SaveChangesAsync();
        }
        return RedirectToAction(nameof(AdminIndex));
    }

    // -----------------------------------------------
    // 🛑 أكشنات الواجهة الأمامية (Store) - للجميع
    // -----------------------------------------------

    [HttpGet]
    [AllowAnonymous] // 👈 هذا الأكشن متاح للجميع
    public async Task<IActionResult> Index()
    {
        // عرض المنتجات للبيع
        var products = await _db.Products.ToListAsync();
        return View(products); // يعرض Views/Products/Index.cshtml
    }
    // 📁 Controllers/ProductsController.cs (تعديل أكشن Details)
    public async Task<IActionResult> Details(int id)
    {
        var product = await _db.Products.FindAsync(id);
        if (product == null)
        {
            return NotFound();
        }

        var viewModel = new ProductDetailViewModel
        {
            ProductId = product.Id,
            Name = product.Name,
            Price = product.Price,
            Description = product.Description,
            ImageUrl = product.ImageUrl,
            ImageUrl_Back = product.ImageUrl_Back, // 👈 أضيفي هذا السطر
            AvailableStock = product.Stock
        };

        return View(viewModel);
    }

}
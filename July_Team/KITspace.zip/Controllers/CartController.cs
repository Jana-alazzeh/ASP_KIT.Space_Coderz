﻿// 📁 Controllers/CartController.cs (نسخة كاملة)
using July_Team.Models;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json; // 🛑 ستحتاجين لإضافة هذه الحزمة

public class CartController : Controller
{
    private readonly AppDbContext _db;

    public CartController(AppDbContext db)
    {
        _db = db;
    }

    // ===============================================
    // عرض صفحة سلة التسوق
    // ===============================================
    public IActionResult Index()
    {
        var cart = GetCart();
        return View(cart);
    }

    // ===============================================
    // إضافة منتج إلى السلة
    // ===============================================
    [HttpPost]
    public async Task<IActionResult> AddToCart(ProductDetailViewModel model)
    {
        var product = await _db.Products.FindAsync(model.ProductId);
        if (product == null)
        {
            return NotFound();
        }

        var cart = GetCart();
        var cartItem = cart.Items.FirstOrDefault(i => i.ProductId == model.ProductId && i.Size == model.SelectedSize);

        if (cartItem == null)
        {
            // إضافة عنصر جديد
            cart.Items.Add(new CartItem
            {
                ProductId = product.Id,
                ProductName = product.Name,
                Price = product.Price,
                Quantity = model.SelectedQuantity,
                Size = model.SelectedSize,
                ImageUrl = product.ImageUrl
            });
        }
        else
        {
            // تحديث الكمية فقط
            cartItem.Quantity += model.SelectedQuantity;
        }

        SaveCart(cart);
        TempData["SuccessMessage"] = $"تمت إضافة '{product.Name}' إلى السلة!";
        return RedirectToAction("Index"); // توجيه إلى صفحة السلة
    }

    // ===============================================
    // تحديث كمية منتج في السلة
    // ===============================================
    [HttpPost]
    public IActionResult UpdateQuantity(int productId, string size, int quantity)
    {
        var cart = GetCart();
        var cartItem = cart.Items.FirstOrDefault(i => i.ProductId == productId && i.Size == size);

        if (cartItem != null)
        {
            if (quantity > 0)
            {
                cartItem.Quantity = quantity;
            }
            else
            {
                // إذا كانت الكمية 0 أو أقل، احذف العنصر
                cart.Items.Remove(cartItem);
            }
            SaveCart(cart);
        }
        return RedirectToAction("Index");
    }

    // ===============================================
    // حذف منتج من السلة
    // ===============================================
    [HttpPost]
    public IActionResult RemoveFromCart(int productId, string size)
    {
        var cart = GetCart();
        var cartItem = cart.Items.FirstOrDefault(i => i.ProductId == productId && i.Size == size);

        if (cartItem != null)
        {
            cart.Items.Remove(cartItem);
            SaveCart(cart);
        }
        return RedirectToAction("Index");
    }


    // ===============================================
    // دوال مساعدة للتعامل مع الـ Session
    // ===============================================
    private CartViewModel GetCart()
    {
        var cartJson = HttpContext.Session.GetString("Cart");
        if (string.IsNullOrEmpty(cartJson))
        {
            return new CartViewModel();
        }
        return JsonConvert.DeserializeObject<CartViewModel>(cartJson);
    }

    private void SaveCart(CartViewModel cart)
    {
        var cartJson = JsonConvert.SerializeObject(cart);
        HttpContext.Session.SetString("Cart", cartJson);
    }
}

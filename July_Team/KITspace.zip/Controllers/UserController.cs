﻿//using July_Team.Models;
//using Microsoft.AspNetCore.Authorization;
//using Microsoft.AspNetCore.Identity;
//using Microsoft.AspNetCore.Mvc;
//using Microsoft.EntityFrameworkCore;

//namespace July_Team.Controllers
//{
//    public class UserController : Controller
//    {
//        private UserManager<IdentityUser> _UserManager;
//        private SignInManager<IdentityUser> _SignInManager;
//        private RoleManager<IdentityRole> _RoleManager;

//        public UserController(UserManager<IdentityUser> userManager, SignInManager<IdentityUser> signInManager, RoleManager<IdentityRole> roleManager)
//        {
//            _UserManager = userManager;
//            _SignInManager = signInManager;
//            _RoleManager = roleManager;
//        }

//        public async Task<IActionResult> Index()
//        {
//            var model= await _UserManager.Users.ToListAsync();

//            return View( model);
//        }

//        [HttpGet]
//        public IActionResult Regester()
//        {
//            return View();
//        }


//        [HttpPost]
//        [ValidateAntiForgeryToken]

//        public async Task<IActionResult> Regester(RegesterModel model)
//        {
//            if (ModelState.IsValid)
//            {
//                var User = new IdentityUser
//                {
//                    UserName = model.User_Email,
//                    Email=model.User_Email
//                };
//                var result =await _UserManager.CreateAsync(User,model.Password);
//                if (result.Succeeded) { return RedirectToAction("index", "home"); }
//                else { return View(model); }

//            }

//            return View(model);
//        }

//        [HttpGet]
//        public IActionResult Login()
//        {
//            return View();
//        }


//        [HttpPost]
//        [ValidateAntiForgeryToken]
//        public async Task<IActionResult> Login(LoginModel model)
//        {
//            if (!ModelState.IsValid)
//            {
//                // إذا كان هناك أخطاء في التحقق من النموذج (مثل حقول فارغة)، أعدي عرض الصفحة
//                return View(model);
//            }

//            // لا حاجة لإنشاء كائن IdentityUser هنا، PasswordSignInAsync تتعامل مباشرة مع البريد وكلمة المرور
//            var result = await _SignInManager.PasswordSignInAsync(model.User_Email, model.Password, model.RememberMe, lockoutOnFailure: false);
//            // ملاحظة: لقد افترضت أن لديكِ خاصية RememberMe في LoginModel. إذا لم يكن كذلك، يمكنكِ وضع false بدلاً منها.
//            // lockoutOnFailure: false تعني عدم قفل الحساب بعد عدد معين من محاولات تسجيل الدخول الفاشلة.

//            if (result.Succeeded)
//            {
//                return RedirectToAction("index", "home");
//            }
//            else
//            {
//                // إذا فشل تسجيل الدخول، أضيفي رسالة خطأ إلى ModelState لعرضها في الواجهة
//                ModelState.AddModelError(string.Empty, "فشل تسجيل الدخول: البريد الإلكتروني أو كلمة المرور غير صحيحة.");
//                return View(model);
//            }
//        }

//        public IActionResult AccessDenied() 
//        { 
//            return View();

//        }

//        public async Task<IActionResult> Logout()
//        { 
//        await _SignInManager.SignOutAsync();
//            return RedirectToAction("index", "home");

//        }

//        [HttpGet]
//        public IActionResult Create_Role()
//        {
//            return View();
//        }
//        [HttpPost]
//        [ValidateAntiForgeryToken]

//        public async Task<IActionResult> Create_Role(string role_name)
//        {
//            if (string.IsNullOrEmpty(role_name))
//            {
//                ViewBag.err = "please enter valied role name"; // هذا السطر صحيح
//                return View();
//            }

//            else
//            {
//                var exist = await _RoleManager.RoleExistsAsync(role_name);
//                if (exist)
//                {
//                    ViewBag.err = "the role name was exist"; // هذا السطر صحيح
//                }
//                else
//                {
//                    var result = await _RoleManager.CreateAsync(new IdentityRole(role_name));
//                    if (result.Succeeded)
//                    {
//                        return RedirectToAction("index", "home");
//                    }
//                    else
//                    {
//                        // إذا فشل إنشاء الدور، أضيفي رسائل الأخطاء إلى ModelState
//                        foreach (var error in result.Errors)
//                        {
//                            ModelState.AddModelError(string.Empty, error.Description);
//                        }
//                    }
//                }
//            }
//            return View();
//        }


//        [HttpGet]
//        public async Task< IActionResult>  Edit_Role(string id)
//        { 
//            var user=await _UserManager.FindByIdAsync(id);
//            if(user == null)
//            {
//                return NotFound();
//            }
//            var model = new UserRolesViewModel
//            {
//                UserId = user.Id,
//                Email = user.Email
//            };
//            foreach (var role in _RoleManager.Roles)
//                model.Roles.Add(new RolesViewModel
//               {
//                            RoleName=role.Name,
//                           IsSelected = await _UserManager.IsInRoleAsync(user, role.Name)
//                       });


//            return View(model);
//        }

//        [HttpPost]
//        [ValidateAntiForgeryToken]
//        public async Task<IActionResult> Edit_Role(UserRolesViewModel model)
//        {
//            var user =await  _UserManager.FindByIdAsync(model.UserId);
//            if (user == null)
//            {
//                return NotFound();

//            }
//            var userRoles = await _UserManager.GetRolesAsync(user);
//            var selectedRoles =model.Roles.Where
//                (r => r.IsSelected).Select(e=>e.RoleName).ToList();

//            await _UserManager.RemoveFromRolesAsync(user,userRoles );
//            await _UserManager.AddToRolesAsync(user, selectedRoles);
//            return View("index");
//        }


//    }

//}
// 📁 Controllers/UserController.cs (النسخة النهائية والمصححة)
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
// 🛑 تأكدي من أن هذا السطر موجود ومساره صحيح
using July_Team.Models; // مسار الـ ViewModels

public class UserController : Controller
{
    private readonly UserManager<IdentityUser> _userManager;
    private readonly SignInManager<IdentityUser> _signInManager;

    public UserController(UserManager<IdentityUser> userManager, SignInManager<IdentityUser> signInManager)
    {
        _userManager = userManager;
        _signInManager = signInManager;
    }

    // ===============================================
    // 1. عرض صفحة إنشاء حساب جديد
    // ===============================================
    [HttpGet]
    public IActionResult Register() // 🛑 تم تصحيح الاسم
    {
        return View();
    }

    // ===============================================
    // 2. استقبال بيانات إنشاء الحساب الجديد
    // ===============================================
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Register(RegesterModel model) // 🛑 تم تصحيح الاسم
    {
        if (ModelState.IsValid)
        {
            var user = new IdentityUser { UserName = model.User_Email, Email = model.User_Email };
            var result = await _userManager.CreateAsync(user, model.Password);

            if (result.Succeeded)
            {
                await _signInManager.SignInAsync(user, isPersistent: false);
                return RedirectToAction("Index", "Home");
            }

            foreach (var error in result.Errors)
            {
                ModelState.AddModelError(string.Empty, error.Description);
            }
        }
        return View(model);
    }

    // ===============================================
    // 3. عرض صفحة تسجيل الدخول
    // ===============================================
    [HttpGet]
    public IActionResult Login()
    {
        return View();
    }

    // ===============================================
    // 4. استقبال بيانات تسجيل الدخول
    // ===============================================
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Login(LoginModel model)
    {
        if (ModelState.IsValid)
        {
            var result = await _signInManager.PasswordSignInAsync(model.User_Email, model.Password, model.RememberMe, lockoutOnFailure: false);

            if (result.Succeeded)
            {
                return RedirectToAction("Index", "Home");
            }
            ModelState.AddModelError(string.Empty, "فشل تسجيل الدخول. الرجاء التحقق من البريد الإلكتروني وكلمة المرور.");
        }
        return View(model);
    }

    // ===============================================
    // 5. تسجيل الخروج
    // ===============================================
    [HttpPost]
    public async Task<IActionResult> Logout()
    {
        await _signInManager.SignOutAsync();
        return RedirectToAction("Index", "Home");
    }
}


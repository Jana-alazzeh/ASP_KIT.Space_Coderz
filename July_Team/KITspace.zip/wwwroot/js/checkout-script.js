document.addEventListener('DOMContentLoaded', () => {
    // عناصر الصفحة
    const orderItemsContainer = document.getElementById('order-items');
    const subtotalSpan = document.getElementById('subtotal');
    const shippingFeeSpan = document.getElementById('shipping-fee');
    const grandTotalSpan = document.getElementById('grand-total');
    const placeOrderBtn = document.getElementById('place-order-btn');
    const checkoutForm = document.getElementById('checkout-form');

    // عناصر النافذة المنبثقة
    const modal = document.getElementById('order-confirmation-modal');
    const confirmationTotalSpan = document.getElementById('confirmation-total');
    const cancelOrderBtn = document.getElementById('cancel-order');
    const confirmOrderBtn = document.getElementById('confirm-order');

    // بيانات افتراضية للسلة (في التطبيق الحقيقي ستأتي من localStorage أو API)
    let cartItems = JSON.parse(localStorage.getItem("cartItems")) || [
        {
            productId: 1,
            productName: 'قميص July Team الأزرق',
            quantity: 2,
            unitPrice: 12.50,
            size: 'L'
        }, // سعر بالدينار الأردني
        {
            productId: 2,
            productName: 'حقيبة July Team الرياضية',
            quantity: 1,
            unitPrice: 20.00,
            size: 'واحد'
        } // سعر بالدينار الأردني
    ];

    let subtotal = 0;
    const shippingFee = 3.00;

    // دالة لعرض عناصر السلة
    function renderOrderItems() {
        orderItemsContainer.innerHTML = '';
        subtotal = 0;

        cartItems.forEach(item => {
            const itemTotal = item.quantity * item.unitPrice;
            subtotal += itemTotal;

            const orderItemElement = document.createElement('div');
            orderItemElement.classList.add('order-item');
            orderItemElement.innerHTML = `\n                <div class="item-info">\n                    <div class="item-name">${item.productName}</div>\n                    <div class="item-details">المقاس: ${item.size} | الكمية: ${item.quantity}</div>\n                </div>\n                <div class="item-price">${itemTotal.toFixed(2)} د.أ</div>\n            `; orderItemsContainer.appendChild(orderItemElement);
        });

        // تحديث المجاميع
        subtotalSpan.textContent = `${subtotal.toFixed(2)} د.أ`;
        shippingFeeSpan.textContent = `${shippingFee.toFixed(2)} د.أ`;
        grandTotalSpan.textContent = `${(subtotal + shippingFee).toFixed(2)} د.أ`;
        confirmationTotalSpan.textContent = `${(subtotal + shippingFee).toFixed(2)} د.أ`;
    }

    // دالة للتحقق من صحة النموذج
    function validateForm() {
        const requiredFields = [
            { id: 'ShippingFullName', errorId: 'fullname-error', message: 'الاسم الكامل مطلوب' },
            { id: 'ShippingAddress', errorId: 'address-error', message: 'العنوان مطلوب' },
            { id: 'ShippingPhoneNumber', errorId: 'phone-error', message: 'رقم الهاتف مطلوب' }
        ];

        let isValid = true;

        requiredFields.forEach(field => {
            const input = document.getElementById(field.id);
            const errorSpan = document.getElementById(field.errorId);

            if (!input.value.trim()) {
                errorSpan.textContent = field.message;
                errorSpan.style.display = 'block';
                input.style.borderColor = '#e53e3e';
                isValid = false;
            } else {
                errorSpan.textContent = '';
                errorSpan.style.display = 'none';
                input.style.borderColor = '#032ba7';
            }
        });

        // التحقق من صحة رقم الهاتف
        const phoneInput = document.getElementById('ShippingPhoneNumber');
        const phoneError = document.getElementById('phone-error');
        const phonePattern = /^(079|078|077)[0-9]{7}$/; // أرقام هواتف أردنية (079, 078, 077)

        if (phoneInput.value.trim() && !phonePattern.test(phoneInput.value.trim())) {
            phoneError.textContent = 'رقم الهاتف الأردني يجب أن يبدأ بـ 079 أو 078 أو 077 ويتكون من 10 أرقام';
            phoneError.style.display = 'block';
            phoneInput.style.borderColor = '#e53e3e';
            isValid = false;
        }

        return isValid;
    }

    // دالة لإظهار النافذة المنبثقة
    function showModal() {
        modal.style.display = 'block';
        document.body.style.overflow = 'hidden';
    }

    // دالة لإخفاء النافذة المنبثقة
    function hideModal() {
        modal.style.display = 'none';
        document.body.style.overflow = 'auto';
    }

    // دالة لتجميع بيانات الطلب
    function collectOrderData() {
        const formData = new FormData(checkoutForm);

        const orderData = {
            ShippingFullName: formData.get('ShippingFullName'),
            ShippingAddress: formData.get('ShippingAddress'),
            ShippingPhoneNumber: formData.get('ShippingPhoneNumber'),
            Notes: formData.get('Notes') || '',
            PaymentMethod: formData.get('PaymentMethod') || 'CashOnDelivery',
            Items: cartItems.map(item => ({
                ProductId: item.productId,
                ProductName: item.productName,
                Quantity: item.quantity,
                UnitPrice: item.unitPrice,
                Size: item.size
            })),
            SubTotal: subtotal,
            ShippingFee: shippingFee,
            GrandTotal: subtotal + shippingFee
        };

        return orderData;
    }

    // دالة لإرسال الطلب إلى الخادم
    async function submitOrder(orderData) {
        try {
            placeOrderBtn.disabled = true;
            placeOrderBtn.innerHTML = '<span class="btn-text">جاري المعالجة...</span>';

            const response = await fetch('/Orders/ProcessCheckout', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'RequestVerificationToken': document.querySelector('#checkout-form input[name="__RequestVerificationToken"]')?.value || ''
                },
                body: JSON.stringify(orderData)
            });

            if (response.ok) {
                const result = await response.json();

                // مسح السلة من localStorage
                localStorage.removeItem('cartItems');

                // إظهار رسالة نجاح
                alert('تم تأكيد طلبك بنجاح! سيتم التواصل معك قريباً.');

                // إعادة توجيه إلى صفحة تأكيد الطلب أو الصفحة الرئيسية
                window.location.href = result.redirectUrl || '/';

            } else {
                const errorData = await response.json();
                alert('حدث خطأ أثناء معالجة طلبك: ' + (errorData.message || 'خطأ غير معروف'));
            }
        } catch (error) {
            console.error('خطأ في إرسال الطلب:', error);
            alert('حدث خطأ في الاتصال. يرجى المحاولة مرة أخرى.');
        } finally {
            placeOrderBtn.disabled = false;
            placeOrderBtn.innerHTML = '<span class="btn-text">تأكيد الطلب</span><span class="btn-icon">🛒</span>';
            hideModal();
        }
    }

    // معالج حدث النقر على زر تأكيد الطلب
    placeOrderBtn.addEventListener('click', (e) => {
        e.preventDefault();

        if (validateForm()) {
            showModal();
        }
    });

    // معالج حدث إلغاء الطلب
    cancelOrderBtn.addEventListener('click', hideModal);

    // معالج حدث تأكيد الطلب النهائي
    confirmOrderBtn.addEventListener('click', () => {
        const orderData = collectOrderData();
        submitOrder(orderData);
    });

    // إغلاق النافذة المنبثقة عند النقر خارجها
    modal.addEventListener('click', (e) => {
        if (e.target === modal) {
            hideModal();
        }
    });

    // إضافة مستمعي الأحداث للحقول لمسح رسائل الخطأ عند الكتابة
    ['ShippingFullName', 'ShippingAddress', 'ShippingPhoneNumber'].forEach(fieldId => {
        const field = document.getElementById(fieldId);
        if (field) {
            field.addEventListener('input', () => {
                const errorSpan = document.getElementById(fieldId.toLowerCase().replace('shipping', '') + '-error');
                if (errorSpan) {
                    errorSpan.style.display = 'none';
                    field.style.borderColor = '#e2e8f0';
                }
            });
        }
    });

    // تشغيل الدالة لعرض العناصر عند تحميل الصفحة
    renderOrderItems();

    // إضافة تأثيرات بصرية للنموذج
    const inputs = document.querySelectorAll('input, textarea');
    inputs.forEach(input => {
        input.addEventListener('focus', () => {
            input.style.transform = 'scale(1.02)';
            input.style.transition = 'all 0.3s ease';
        });

        input.addEventListener('blur', () => {
            input.style.transform = 'scale(1)';
        });
    });
});
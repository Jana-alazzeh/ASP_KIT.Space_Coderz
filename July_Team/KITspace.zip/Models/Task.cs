﻿// 📁 Models/Task.cs
using System.ComponentModel.DataAnnotations;

namespace July_Team.Models
{
    public enum TaskStatus { Pending, Done } // الـ Enum للحالة

    public class Task
    {
        [Key]
        public int Id { get; set; }
        [Required]
        public string Title { get; set; }
        public string Description { get; set; }
        public DateTime DueDate { get; set; }
        public TaskStatus Status { get; set; } = TaskStatus.Pending; // القيمة الافتراضية

        // AssignedTo هو مفتاح أجنبي لـ IdentityUser.Id (عادة ما تكون string)
        public string OwnerId { get; set; }
        // [ForeignKey("AssignedToId")]
        // public IdentityUser AssignedTo { get; set; } 
    }
}
﻿namespace July_Team.Models
{
    public class RolesViewModel
    {
        public  string RoleName { get; set; }
        public bool IsSelected { get; set; }
    }
}

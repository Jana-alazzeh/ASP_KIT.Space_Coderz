﻿// 📁 Models/AppDbContext.cs (الكود المُعدَّل)
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace July_Team.Models
{
    // ملاحظة: IdentityUser هو جدول المستخدمين (Users)
    // IdentityRole هو جدول الصلاحيات (Roles)
    public class AppDbContext : IdentityDbContext<IdentityUser>
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
        {
        }

        // 🛑 جداول KIT Space المطلوبة
        public DbSet<Product> Products { get; set; } // تم إضافته
        public DbSet<Order> Orders { get; set; }     // تم إضافته
        public DbSet<Course> Courses { get; set; }   // تم إضافته
        public DbSet<Task> Tasks { get; set; }       // تم إضافته

        // 🛑 حذف الجداول القديمة (Employees/Departments)
        // public DbSet<Employee> Employees { get; set; } 
        // public DbSet<Department> Departments { get; set; } 
        // إذا كنتِ تريدين إضافة حقول لـ IdentityUser (مثل FullName):
        // عليكِ إنشاء نموذج مخصص مثل ApplicationUser يرث من IdentityUser
        // public DbSet<ApplicationUser> ApplicationUsers { get; set; } 

        // لإضافة الـ Seed Data للدور (Roles)
        //protected override void OnModelCreating(ModelBuilder builder)
        //{
        //    base.OnModelCreating(builder);
        //    // إضافة الأدوار المطلوبة للمشروع
        //    builder.Entity<IdentityRole>().HasData(
        //        new IdentityRole { Name = "Admin", NormalizedName = "ADMIN" },
        //        new IdentityRole { Name = "Trainer", NormalizedName = "TRAINER" },
        //        new IdentityRole { Name = "User", NormalizedName = "USER" }
        //    );
        //}
    }
}
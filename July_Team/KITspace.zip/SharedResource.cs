﻿namespace July_Team
{
    public class SharedResource
    {
    }
}
